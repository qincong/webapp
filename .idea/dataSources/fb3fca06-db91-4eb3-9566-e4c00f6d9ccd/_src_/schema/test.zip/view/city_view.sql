CREATE VIEW city_view AS
  SELECT `test`.`city`.`cityname` AS `cityname`
  FROM `test`.`city`
  WHERE (`test`.`city`.`people` > 2000);
