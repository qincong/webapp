CREATE VIEW qc_view AS
  SELECT
    `test`.`city`.`cityname` AS `cityname`,
    `test`.`city`.`people`   AS `people`
  FROM `test`.`city`
  WHERE (`test`.`city`.`cityname` = 'bj');
